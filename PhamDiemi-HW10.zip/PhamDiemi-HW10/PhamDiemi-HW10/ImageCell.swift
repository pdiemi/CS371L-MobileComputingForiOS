//
//  ImageCell.swift
//  PhamDiemi-HW10
//
//  Created by Pham, Diemi on 8/15/18.
//  Copyright © 2018 Pham, Diemi. All rights reserved.
//

import UIKit

class ImageCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
 /*
    override init(frame: CGRect) {
        super.init(frame: frame)
        let image = UIImageView()
        image.contentMode = .scaleAspectFill
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
 */
}
