//
//  ViewController.swift
//  PhamDiemi-HW5
//  EID: mp43952
//  Course: CS371L
//
//  Created by Pham, Diemi on 7/30/18.
//  Copyright © 2018 Pham, Diemi. All rights reserved.
//

import UIKit

let initNote = Note(s: "welcome to Quick notes!")
public var notes: [Note] = [initNote]

let textCellIdentifier = "textNoteTableViewCell"

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIPopoverPresentationControllerDelegate {
    
    @IBOutlet var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.dataSource = self
        tableView.delegate = self
        NotificationCenter.default.addObserver(self, selector: #selector(loadList), name: NSNotification.Name(rawValue: "load"), object: nil)
    }
    
    //
    //  Helper function to reload the table view with the new added note
    //
    @objc func loadList() {
        self.tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // To conform to UITableViewDataSource, you must implement
    // 3 methods:
    //    1.  numberOfSectionsInTableView
    //    2.  tableView:numberOfRowsInSection
    //    3.  tableView:cellForRowAtIndexPath
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection
        section: Int) -> Int {
        return notes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier:
            textCellIdentifier, for: indexPath as IndexPath) as! textNoteTableViewCell
        let row = indexPath.row
        //cell.textLabel?.text = notes[row]
        cell.note = notes[row]
        cell.labelDate.text = notes[row].getDate()
        cell.labelTime.text = notes[row].getTime()
        cell.labelNotes.text = notes[row].str
        return cell
    }
    //
    // Prepare for segue to Popover View Controller, avoid full screen popover
    //
    override func prepare(for segue: UIStoryboardSegue, sender: (Any)?) {
        if segue.identifier == "popoverSegue" {
            let destination = segue.destination as? PopoverViewController
            destination?.popoverPresentationController?.delegate = self
        }
    }
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none
    }
}

