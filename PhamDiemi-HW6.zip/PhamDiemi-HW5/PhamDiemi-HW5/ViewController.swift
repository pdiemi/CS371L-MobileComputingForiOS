//
//  ViewController.swift
//  PhamDiemi-HW5
//  EID: mp43952
//  Course: CS371L
//
//  Created by Pham, Diemi on 7/30/18.
//  Copyright © 2018 Pham, Diemi. All rights reserved.
//
//  This is HW6 - Note Application 2.0
//  HW6 is built on top of HW5 with core data
//

import UIKit
import Firebase
import CoreData

//let initNote = Note(s: "welcome to Quick notes!")
//public var notes: [Note] = [initNote]

let textCellIdentifier = "NoteTableViewCell"
var notes: [NSManagedObject] = []

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIPopoverPresentationControllerDelegate, NewNoteDelegate {
    
    @IBOutlet var tableView: UITableView!
    //
    //  Flags - addNewNote: true if adding a new note, false if updating selected note
    //        - selectedNoteIndex: index of selected note
    //        - selected note: content of selected note, will be display to popover controller
    //
    var selectedNote: String?
    var selectedNoteIndex: Int?
    var addNewNote: Bool = true
    
    let ref = Database.database().reference(withPath: "Note")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        FirebaseApp.configure()
        ref.observe(.value, with: { snapshot in print(snapshot.value as Any)})
        tableView.dataSource = self
        tableView.delegate = self
        
        // Fetch all of the Notes from Core Data
        notes = retrieveNotes()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // To conform to UITableViewDataSource, you must implement
    // 3 methods:
    //    1.  numberOfSectionsInTableView
    //    2.  tableView:numberOfRowsInSection
    //    3.  tableView:cellForRowAtIndexPath
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection
        section: Int) -> Int {
        return notes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:
            textCellIdentifier, for: indexPath as IndexPath) as! NoteTableViewCell
        let row = indexPath.row
        //cell.textLabel?.text = notes[row]
        cell.note = notes[row]
        cell.labelNotes.text = notes[row].value(forKey: "body") as? String
        cell.labelDate.text = getDate(notes[row].value(forKey: "date") as! Date)
        cell.labelTime.text = getTime(notes[row].value(forKey: "date") as! Date)
        return cell
    }
    
    //
    //  This method is called when a tableview cell is clicked.
    //  The method resets flags and performs a segue to a popover view controller
    //  for updating content of the selected Note.
    //
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedNoteIndex = indexPath.row
        selectedNote = notes[indexPath.row].value(forKey: "body") as? String
        addNewNote = false
        performSegue(withIdentifier: "popoverSegue", sender: self)
    }
    
    //
    // Method used to get date and time from a NSDate
    //
    func getDate(_ date: Date) -> String {
        let myDateFormat = DateFormatter()
        myDateFormat.dateFormat = "MM/dd/yyyy"
        return myDateFormat.string(from: date as Date)
    }
    
    func getTime(_ date: Date) -> String {
        let myDateFormat = DateFormatter()
        myDateFormat.dateFormat = "HH:mm"
        return myDateFormat.string(from: date as Date)
    }
    
    //
    //  Conform to NewnoteDelegate
    //
    func updateNewNote(s: String) {
        if addNewNote { //Add a new note
            storeNote(s: s)
        } else { // Update selected note
            notes[selectedNoteIndex!].str = s
        }
        selectedNote = ""
        addNewNote = true
        tableView.reloadData()
    }
    func resetFlags(isNewNote: Bool, currentText: String) {
        addNewNote = isNewNote
        selectedNote = currentText
        if let index = self.tableView.indexPathForSelectedRow{
            self.tableView.deselectRow(at: index, animated: true) }
    }
    
    //
    // Prepare for segue to Popover View Controller, avoid full screen popover
    //
    override func prepare(for segue: UIStoryboardSegue, sender: (Any)?) {
        if segue.identifier == "popoverSegue" {
            let destination = segue.destination as? PopoverViewController
            destination?.popoverPresentationController?.delegate = self
            destination?.delegate = self
            
            if !addNewNote {  // Update selected note
                destination?.isNewNote = addNewNote
                destination?.currentText = selectedNote!
            }
        }
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none
    }
    
    //
    // ** Core Data methods **
    //
    
    //
    // Method used to retrieve all Notes from Data Core
    //
    func retrieveNotes() -> [NSManagedObject] {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Note")
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        return(fetchedResults)!
    }
    
    //
    // Method used to save a new Note to Core Data
    //
    
    func storeNote(s: String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let newNote = NSEntityDescription.insertNewObject(
            forEntityName: "Note", into: context)
        let date = NSDate()
        
        // Set the attribute values
        newNote.setValue(s, forKey: "body")
        newNote.setValue(date, forKey: "date")
        
        // Commit the changes
        do {
            try context.save()
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }

}

