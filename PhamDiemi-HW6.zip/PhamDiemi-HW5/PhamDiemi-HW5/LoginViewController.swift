//
//  LoginViewController.swift
//  PhamDiemi-HW5
//
//  Created by Pham, Diemi on 8/2/18.
//  Copyright © 2018 Pham, Diemi. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var segmentSignIn: UISegmentedControl!
    @IBOutlet weak var textFieldUsername: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    @IBOutlet weak var textFiedConfirmPassword: UITextField!
    @IBOutlet weak var labelConfirmPassword: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var buttonSignIn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        segmentSignIn.selectedSegmentIndex = 0
        labelConfirmPassword.isHidden = true
        textFiedConfirmPassword.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func segmentSignInValueChanged(_ sender: Any) {
        switch segmentSignIn.selectedSegmentIndex {
        case 0:
            buttonSignIn.setTitle("Sign In", for: .normal)
            labelConfirmPassword.isHidden = true
            textFiedConfirmPassword.isHidden = true
            break
        case 1:
            buttonSignIn.setTitle("Sign Up", for: .normal)
            labelConfirmPassword.isHidden = false
            textFiedConfirmPassword.isHidden = false
        default:
            break
        }
    }
    
    
    @IBAction func buttonSignInPressed(_ sender: Any) {
        let username = textFieldUsername.text!
        let password = textFieldPassword.text!
        let passwordConfirm = textFiedConfirmPassword.text!
        
        // Check empty input
        if (username == "" || password == "") {
            labelStatus.text = "Invalid username or password"
            return
        }
        
        // Check password match for signing up
        if (password != passwordConfirm) {
            labelStatus.text = "password does not match"
            return
        }
        
        switch buttonSignIn.titleLabel?.text {
        case "Sign In":
            doSignin(username, password)
            textFieldUsername.text = ""
            textFieldPassword.text = ""
        case "Sign Up":
            doSignup(username, password)
        default:
            break
        }
    }
    
    func doSignup(_ username: String, _ password: String) {
        //Get a reference to the global user defaults object
        let defaults = UserDefaults.standard
        
        // Define keys for the values to store
        let usernameKey = "username"
        let passowrdKey = "password"
        
        // Store the values
        defaults.set(username, forKey: usernameKey)
        defaults.set(password, forKey: passowrdKey)
        defaults.synchronize()
        
        labelStatus.text = "Welcome to Quick Notes, " + username + "!"
    }
    
    func doSignin(_ username: String, _ password: String) {
        // Get a reference to the global user defaults object
        let defaults = UserDefaults.standard
        
        // Retrieve stored information for input username and password
        let usernameStored = defaults.string(forKey: "username")
        let passwordStored = defaults.string(forKey: "password")
        
        if (usernameStored != username || passwordStored != password) {
            // Signin unsuccessful
            labelStatus.text = "Incorrect username or password"
        } else { // Signin successful
            defaults.set(true, forKey: "isSignedIn")
            defaults.synchronize()
            labelStatus.text = username + " has signed in successfully"
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none
    }

}
