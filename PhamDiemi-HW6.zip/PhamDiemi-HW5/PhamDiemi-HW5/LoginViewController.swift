//
//  LoginViewController.swift
//  PhamDiemi-HW5
//
//  Created by Pham, Diemi on 8/2/18.
//  Copyright © 2018 Pham, Diemi. All rights reserved.
//
//  This is HW6 - Note Application 2.0
//  HW6 is built on top of HW5 with core data
//

import UIKit
import Firebase
import FirebaseAuth

class LoginViewController: UIViewController {

    @IBOutlet weak var segmentSignIn: UISegmentedControl!
    @IBOutlet weak var textFieldUsername: UITextField!
    @IBOutlet weak var textFieldPassword: UITextField!
    @IBOutlet weak var textFiedConfirmPassword: UITextField!
    @IBOutlet weak var labelConfirmPassword: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var buttonSignIn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        segmentSignIn.selectedSegmentIndex = 0
        labelConfirmPassword.isHidden = true
        textFiedConfirmPassword.isHidden = true
        labelStatus.textColor = UIColor.black
        labelStatus.text = "Welcom to Quick Notes!"
        
        Auth.auth().addStateDidChangeListener() { auth, user in
            if user != nil {
                // do something...
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func segmentSignInValueChanged(_ sender: Any) {
        labelStatus.textColor = UIColor.black
        labelStatus.text = "Welcom to Quick Notes!"
        textFieldUsername.text = ""
        textFieldPassword.text = ""
        textFiedConfirmPassword.text = ""
        
        switch segmentSignIn.selectedSegmentIndex {
        case 0:
            buttonSignIn.setTitle("Sign In", for: .normal)
            labelConfirmPassword.isHidden = true
            textFiedConfirmPassword.isHidden = true
            break
        case 1:
            buttonSignIn.setTitle("Sign Up", for: .normal)
            labelConfirmPassword.isHidden = false
            textFiedConfirmPassword.isHidden = false
        default:
            break
        }
    }
    
    
    @IBAction func buttonSignInPressed(_ sender: Any) {
        let username = textFieldUsername.text!
        let password = textFieldPassword.text!
        let passwordConfirm = textFiedConfirmPassword.text!
        
        // Check empty input
        if (username == "" || password == "") {
            labelStatus.textColor = UIColor.red
            labelStatus.text = "Invalid username or password"
            return
        }
        
        switch buttonSignIn.titleLabel?.text {
        case "Sign In":
            doSignin(username, password)
        case "Sign Up":
            // Check password match for signing up
            if (password != passwordConfirm) {
                labelStatus.textColor = UIColor.red
                labelStatus.text = "password does not match"
                return
            }
            doSignup(username, password)
        default:
            break
        }
    }
    
    func doSignup(_ username: String, _ password: String) {
        
        Auth.auth().createUser(withEmail: username, password: password) { AuthDataResult, error in
            
            guard let _ = AuthDataResult?.user.email, error == nil
                    else {
                        let alert = UIAlertController(title: "Sign Up Failed",
                                                      message: error?.localizedDescription,
                                                      preferredStyle: .alert)
                            
                        alert.addAction(UIAlertAction(title: "OK", style: .default))
                            
                        self.present(alert, animated: true, completion: nil)
                        return
                    }
            }
        labelStatus.textColor = UIColor.blue
        labelStatus.text = "You signed up successfully"
        
        textFieldUsername.text = ""
        textFieldPassword.text = ""
        textFiedConfirmPassword.text = ""
        
    }
    
    
    func doSignin(_ username: String, _ password: String) {
       
        Auth.auth().signIn(withEmail: username, password: password) { user, error in
            if let error = error, user == nil {
                let alert = UIAlertController(title: "Sign In Failed",
                                              message: error.localizedDescription,
                                              preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                
                self.present(alert, animated: true, completion: nil)
            }
        }
        labelStatus.textColor = UIColor.blue
        labelStatus.text = "You have signed in successfully"
        textFieldUsername.text = ""
        textFieldPassword.text = ""
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none
    }
    
    // This method is called when the user touches the Return key on the
    // keyboard. The 'textField' passed in is a pointer to the textField
    // widget the cursor was in at the time they touched the Return key on
    // the keyboard.
    //
    // From the Apple documentation: Asks the delegate if the text field
    // should process the pressing of the return button.
    //
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user touches on the main view (outside the UITextField).
    //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }


}
