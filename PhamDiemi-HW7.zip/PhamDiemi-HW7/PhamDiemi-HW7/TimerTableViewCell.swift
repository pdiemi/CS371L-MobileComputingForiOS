//
//  TimerTableViewCell.swift
//  PhamDiemi-HW7
//
//  Created by Pham, Diemi on 8/6/18.
//  Copyright © 2018 Pham, Diemi. All rights reserved.
//

import UIKit


class TimerTableViewCell: UITableViewCell {

    @IBOutlet weak var labelEvent: UILabel!
    @IBOutlet weak var labelLocation: UILabel!
    @IBOutlet weak var labelRemainingTime: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
