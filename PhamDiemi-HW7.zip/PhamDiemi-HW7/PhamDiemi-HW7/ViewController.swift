//
//  ViewController.swift
//  PhamDiemi-HW7
//
//  Created by Pham, Diemi on 8/6/18.
//  Copyright © 2018 Pham, Diemi. All rights reserved.
//

import UIKit

let timerCellIdentifier = "TimerTable-ViewCell"

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, NewTimerDelegate {
    
    @IBOutlet weak var tableviewTimer: UITableView!
    
    var timers: [Timer]!
    var selectedTimerIndex: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tableviewTimer.dataSource = self
        tableviewTimer.delegate = self
        
        tableviewTimer.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // To conform to UITableViewDataSource, you must implement
    // 3 methods:
    //    1.  numberOfSectionsInTableView
    //    2.  tableView:numberOfRowsInSection
    //    3.  tableView:cellForRowAtIndexPath
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection
        section: Int) -> Int {
        return timers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> TimerTableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:
            timerCellIdentifier, for: indexPath as IndexPath) 
        let row = indexPath.row
        //cell.textLabel?.text = notes[row]
        cell.timer = timers[row]
        cell.labelEvent.text = "Event\t \(String(describing: timers[row].value(forKey: "event") as? String))"
        cell.labelLocation.text = "Location \(String(describing: timers[row].value(forKey: "location") as? String))"
        cell.labelRemainingTime.text = "Remaining time(s) \(String(describing: timers[row].value(forKey: "remainingTime") as? String))"
        return cell
    }
    
    //
    //  This method is called when a tableview cell is clicked.
    //  The method resets flags and performs a segue to Countdown view controller
    //
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedTimerIndex = indexPath.row
        performSegue(withIdentifier: "countdownSegue", sender: self)
    }
    
    //
    // Prepare for segues
    //
    override func prepare(for segue: UIStoryboardSegue, sender: (Any)?) {
        if segue.identifier == "addSegue" {
            let destination = segue.destination as? AddViewController
            destination?.delegate = self
        }
        if segue.identifier == "countdownSegue" {
            let destination = segue.destination as? CountdownViewController
            //destination?.delegate = self
        }
    }
    
    //
    // Delegate stubs for NewTimerDelegate
    //
    func addTimer(event: String, location: String, totalTime: Int64) {
        // Strore the new timer passed from AddViewCOntroller to Core Data
        storeTimer(event: event, location: location, remainingTime: totalTime)
    }
    
    //
    // Method used to save a new Note to Core Data
    //
    
    func storeTimer(event: String, location: String, remainingTime: Int64) {
        
    }
    
    //
    // Method used to update remaining time of a Timer[index]
    //
    
    func updateNote(remainingTime: Int64, index: Int) {
        
    }

}

