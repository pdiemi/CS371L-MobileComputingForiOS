//
//  ViewController.swift
//  PhamDiemi-HW7
//
//  Created by Pham, Diemi on 8/6/18.
//  Copyright © 2018 Pham, Diemi. All rights reserved.
//

import UIKit
import CoreData
import Firebase

let timerCellIdentifier = "TimerTableViewCell"

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, NewTimerDelegate {
    
    @IBOutlet weak var tableviewTimer: UITableView!
    
    var ref: DatabaseReference!
    
    var timers: [NSManagedObject]!
    var selectedTimerIndex: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        ref = Database.database().reference(withPath: "Timer")
        ref.observe(.value, with: { snapshot in print(snapshot.value as Any)})
        
        tableviewTimer.dataSource = self
        tableviewTimer.delegate = self
        
        // Fetch all of the timer from Core Data
        timers = retrieveTimers()
        tableviewTimer.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // To conform to UITableViewDataSource, you must implement
    // 3 methods:
    //    1.  numberOfSectionsInTableView
    //    2.  tableView:numberOfRowsInSection
    //    3.  tableView:cellForRowAtIndexPath
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection
        section: Int) -> Int {
        return timers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:
            timerCellIdentifier, for: indexPath as IndexPath) as! TimerTableViewCell
        let row = indexPath.row
        //cell.textLabel?.text = notes[row]
        cell.timer = timers[row]
        cell.labelEvent.text = "Event\t \(String(describing: timers[row].value(forKey: "event") as? String))"
        cell.labelLocation.text = "Location \(String(describing: timers[row].value(forKey: "location") as? String))"
        cell.labelRemainingTime.text = "Remaining time(s) \(String(describing: timers[row].value(forKey: "remainingTime") as? String))"
        return cell
    }
    
    //
    //  This method is called when a tableview cell is clicked.
    //  The method resets flags and performs a segue to Countdown view controller
    //
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedTimerIndex = indexPath.row
        performSegue(withIdentifier: "countdownSegue", sender: self)
    }
    
    //
    // Prepare for segues
    //
    override func prepare(for segue: UIStoryboardSegue, sender: (Any)?) {
        if segue.identifier == "addSegue" {
            let destination = segue.destination as? AddViewController
            destination?.delegate = self
        }
        if segue.identifier == "countdownSegue" {
            let destination = segue.destination as? CountdownViewController
            //destination?.delegate = self
        }
    }
    
    //
    // Delegate stubs for NewTimerDelegate
    //
    func addTimer(event: String, location: String, totalTime: Int64) {
        // Strore the new timer passed from AddViewCOntroller to Core Data
        storeTimer(event: event, location: location, remainingTime: totalTime)
    }
    
    
    //
    // ** Core Data methods **
    //
    
    //
    // Method used to retrieve all Timers from Data Core
    //
    func retrieveTimers() -> [NSManagedObject] {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Timer")
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        return(fetchedResults)!
    }
    
    //
    // Method used to save a new Note to Core Data
    //
    
    func storeTimer(event: String, location: String, remainingTime: Int64) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let newTimer = NSEntityDescription.insertNewObject(
            forEntityName: "Timer", into: context)
        
        // Set the attribute values
        newTimer.setValue(event, forKey: "event")
        newTimer.setValue(location, forKey: "location")
        newTimer.setValue(remainingTime, forKey: "remainingTime")
        
        // Commit the changes
        do {
            try context.save()
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }
    
    //
    // Method used to update remaining time of a Timer[index]
    //
    
    func updateNote(remainingTime: Int64, index: Int) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        // Update the attribute values
        timers[index].setValue(remainingTime, forKey: "remainingTime")
        
        // Commit the changes
        do {
            try context.save()
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }

}

